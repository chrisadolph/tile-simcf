
# Example 1:  A tile layout template

trace1 <- textTile("Plot Area 1", x=500, y=50, plot=1)
trace2 <- textTile("Plot Area 2", top=500, right=50, plot=2)
trace3 <- textTile("Plot Area 3", x=500, y=50, plot=3)
trace4 <- textTile("Plot Area 4", top=500, right=50, plot=4)
trace5 <- textTile("Plot Area 5", x=500, y=50, plot=5)
trace6 <- textTile("Plot Area 6", top=500, right=50, plot=6)

at.x <- c(1,5,10,20,35)
at.y <- c(0,0.2,0.4,0.6,0.8,1)

tc <- tile(trace1,
           trace2,
           trace3,
           trace4,
           trace5,
           trace6,

           # Plotting options
           RxC=c(2,3),             # Tile 2 rows & 3 columns of plots
           
           gridlines=list(type="xytr"),

           limits=c(0.1,1000,        # min(x), max(x)
                    0,100,           # min(y), max(y)
                    0.1,1000,        # min(top), max(top)
                    0,100),          # min(right), max(right)
           
           xaxis=list(            # User provided tick locations
             log1=10,
             log3=10,
             log5=10
             ),
           
           xaxistitle=list(labels1="X Axis 1",
             labels3="X Axis 3",
             labels5="X Axis 5"),

           topaxis=list(at=at.x,            # User provided tick locations
                        log1=10,
                        log3=10,
                        log5=10
                        ),
 
           topaxistitle=list(labels2="Top Axis 2",
             labels4="Top Axis 4",
             labels6="Top Axis 6"),

           yaxistitle=list(labels1="Y Axis 1",
             labels3="Y Axis 3",
             labels5="Y Axis 5"),
 
           rightaxistitle=list(labels2="Right Axis 2",
             labels4="Right Axis 4",
             labels6="Right Axis 6"),
           
           plottitle=list(fontface="bold",
                          labels=c("Plot Title 1",
                                   "Plot Title 2",
                                   "Plot Title 3",
                                   "Plot Title 4",
                                   "Plot Title 5",
                                   "Plot Title 6")
                          ),
           
           maintitle=list(fontface="bold",
                          labels=c("Main title")
                          ),
           
           rowtitle=list(labels=c("Row Title 1",
                                  "Row Title 2")
                         ),
           
           columntitle=list(labels=c("Column Title 1",
                                     "Column Title 2",
                                     "Column Title 3")
                                     ),
           
           undertitle=list(fontface="italic",
                           labels=c("Under Title 1",
                                    "Under Title 2",
                                    "Under Title 3",
                                    "Under Title 4",
                                    "Under Title 5",
                                    "Under Title 6")
                           ),

           frame=TRUE
           )
